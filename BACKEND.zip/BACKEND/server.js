// // import dotenv from "dotenv";
// // import authRoute from "./src/routes/authRoutes.js"
// // dotenv.config();

// // import app from "./src/app.js";
// // import { connectDB } from "./src/config/db.js";



// // import path from "path";
// // import imageRoutes from "./src/routes/imageRoutes.js";


// // const PORT = process.env.PORT || 5000;

// // connectDB();

// // app.listen(PORT, () => {
// //   console.log(`🚀 Backend running on http://localhost:${PORT}`);
// // });

// // app.use("/api/authroute",authRoute)


// import dotenv from "dotenv";
// dotenv.config();

// import app from "./src/app.js";
// import { connectDB } from "./src/config/db.js";

// import authRoutes from "./src/routes/authRoutes.js";
// import imageRoutes from "./src/routes/imageRoutes.js";

// const PORT = process.env.PORT || 5000;

// connectDB();

// // ✅ Register routes BEFORE listen
// app.use("/api/auth", authRoutes);
// app.use("/api/images", imageRoutes);

// app.listen(PORT, () => {
//   console.log(`🚀 Backend running on http://localhost:${PORT}`);
// });


import dotenv from "dotenv";
dotenv.config();

import app from "./src/app.js";
import { connectDB } from "./src/config/db.js";

const PORT = process.env.PORT || 5000;

connectDB();

app.listen(PORT, () => {
  console.log(`🚀 Backend running on http://localhost:${PORT}`);
});
