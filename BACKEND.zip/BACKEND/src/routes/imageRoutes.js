import express from "express";
import Image from "../models/image.js";
import { upload } from "../config/multer.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();


router.get("/test", (req, res) => {
  res.json({ message: "✅ imageRoutes is working" });
});


/**
 * POST /api/images/upload
 * Protected route: only logged-in users can upload
 */
router.post("/upload", protect, upload.single("image"), async (req, res) => {
  try {
    // multer puts file details inside req.file
    if (!req.file) {
      return res.status(400).json({ message: "No image uploaded" });
    }

    // save image data in MongoDB
    const newImage = await Image.create({
      ownerId: req.user.id,
      originalName: req.file.originalname,
      fileName: req.file.filename,
      filePath: `/uploads/${req.file.filename}`,
      mimeType: req.file.mimetype,
      size: req.file.size,
    });

    return res.status(201).json({
      message: "Image uploaded successfully",
      image: newImage,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

/**
 * GET /api/images/my
 * Protected route: show logged user's images only
 */
router.get("/my", protect, async (req, res) => {
  try {
    const images = await Image.find({ ownerId: req.user.id }).sort({
      createdAt: -1,
    });

    return res.json(images);
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

export default router;
