import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";

import Home from "./pages/Home";
import About from "./pages/About";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Extra from "./pages/Extra";
import NotFound from "./pages/NotFound";
import Dashboard from "./pages/Auth/Dashboard";
import Register from "./pages/Auth/Register";
import Login from "./pages/Auth/Login";
import UploadImage from "./pages/Auth/Dashboard/UploadImage";
import MyImages from "./pages/Auth/Dashboard/MyImages";
import ProtectedRoute from "./components/ProtectedRoute";
import Upload from "./pages/upload";


const App = () => {
  return (
    <Routes>
      {/* HOME ROUTE */}
      <Route path="/" element={<Layout><Home /></Layout>}/>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={< Register />} />
      <Route path="/my-images" element={<MyImages />} />
      <Route path="/upload" element={<Upload />} />

        {/* Protected (UI only for now) */}
      <Route path="/dashboard" element={ <ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/upload" element={<ProtectedRoute><UploadImage /></ProtectedRoute>} />
      <Route path="/about" element={<Layout><About /></Layout>}/>
      <Route path="/profile" element={<ProtectedRoute><Layout><Profile /></Layout></ProtectedRoute>}/>
      <Route path="/settings" element={<ProtectedRoute><Layout><Settings /></Layout></ProtectedRoute>}/>
      <Route path="/extra" element={<Layout><Extra /></Layout>}/>
      {/* 404 — MUST BE LAST */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default App;
