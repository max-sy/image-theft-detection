import "./css/Footer.css";

const Footer = () => {
  return (
    <footer className="footer">
      <p>© 2026 Reacty App</p>
    </footer>
  );
};

export default Footer;
