import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./css/Navbar.css";

const Navbar = () => {
  const navigate = useNavigate();

  const [user, setUser] = useState(null);
  const [openDropdown, setOpenDropdown] = useState(false);
  const dropdownRef = useRef(null);

  // ✅ Load user from localStorage
  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    } else {
      setUser(null);
    }
  }, []);

  // ✅ Close dropdown if click outside
  useEffect(() => {
    const handleOutsideClick = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setOpenDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, []);

  // ✅ Logout
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    setUser(null);
    setOpenDropdown(false);

    navigate("/login");
  };

  return (
    <nav className="navbar">
      <h2 className="logo">I T D</h2>

      <button onClick={() => navigate("/")} className="fa-faHome">
        Home
      </button>

      <button onClick={() => navigate("/dashboard")}>Dashboard</button>

      {/* ✅ If user not logged in, show Profile button normally */}
      {!user ? (
        <>
          <button onClick={() => navigate("/profile")} className="fa-faUser">
            Profile
          </button>

          <button onClick={() => navigate("/settings")} className="fa-faCog">
            Settings
          </button>

          <button onClick={() => navigate("/login")} className="fa-faPlus">
            Login
          </button>
        </>
      ) : (
        <>
          {/* ✅ Settings visible for logged-in users too */}
          <button onClick={() => navigate("/settings")} className="fa-faCog">
            Settings
          </button>

          {/* ✅ Dropdown button in same format */}
          <div className="profile-dropdown-wrap" ref={dropdownRef}>
            <button
              onClick={() => setOpenDropdown((prev) => !prev)}
              className="fa-faUser"
            >
              {user?.name || "Profile"} ▾
            </button>

            {openDropdown && (
              <div className="profile-dropdown">
                <p className="drop-name">{user?.name}</p>
                <p className="drop-email">{user?.email}</p>

                <button
                style={{color:"black"}}
                  className="drop-btn"
                  onClick={() => {
                    setOpenDropdown(false);
                    navigate("/profile");
                  }}
                >
                  My Profile
                </button>

                <button
                style={{color:"black"}}
                  className="drop-btn"
                  onClick={() => {
                    setOpenDropdown(false);
                    navigate("/dashboard");
                  }}
                >
                  Dashboard
                </button>

                <button className="drop-btn logout" onClick={handleLogout}>
                  Logout
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </nav>
  );
};

export default Navbar;
