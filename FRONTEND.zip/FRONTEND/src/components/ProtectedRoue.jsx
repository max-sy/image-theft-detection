import { Navigate } from "react-router-dom";

const ProtectedRoute = ({ children }) => {
  const isLoggedIn = false; // replace later with auth logic

  return isLoggedIn ? children : <Navigate to="/login" />;
};

export default ProtectedRoute;


// <Route
//   path="/upload"
//   element={
//     <ProtectedRoute>
//       <Upload />
//     </ProtectedRoute>
//   }
// />
