import { Link } from "react-router-dom";
import "./css/Sidebar.css";
import { useNavigate } from "react-router-dom";

const Sidebar = () => {
    const navigate = useNavigate();
  return (
   <>
    <nav className="sidebar">
        
            <button onClick={() => navigate("/")}  className="fa-faHome">Home</button>
            <button onClick={() => navigate("/about")} >About</button>
            <button onClick={() => navigate("/profile")}  className="fa-faUser">Profile</button>
            <button onClick={() => navigate("/settings")}  className="fa-faCog">Settings</button>
            <button onClick={() => navigate("/upload")}  className="fa-faPlus">Upload</button>
    
    </nav>
   </>
  );
};

export default Sidebar;
