import "./css/About.css";

const About = () => {
  return (
    <div className="page">
      <h1>About</h1>
      <p>This application is built using React and Vite.</p>
    </div>
  );
};

export default About;
