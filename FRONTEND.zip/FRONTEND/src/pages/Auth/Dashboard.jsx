import { useEffect, useState } from "react";
import api from "../../services/api"; // ✅ adjust path if needed
import "./Dashboard.css";

const Dashboard = () => {
  const [user, setUser] = useState(null);

  // ✅ Fetch user from backend (/me)
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await api.get("/api/auth/me");
        setUser(res.data.user);
      } catch (error) {
        console.log("Dashboard user fetch error:", error?.response?.data || error.message);
        setUser(null);
      }
    };

    fetchUser();
  }, []);

  return (
    <div className="dashboard-page">
      <h1 className="dashboard-title">Dashboard</h1>

      {/* ✅ USER WELCOME */}
      {user && (
        <div className="user-welcome-card">
          <h2>Welcome, {user.name} 👋</h2>
          <p>{user.email}</p>
        </div>
      )}

      {/* STATS SECTION */}
      <div className="stats-grid">
        <div className="stat-card">
          <h3>Total Images</h3>
          <p>12</p>
        </div>

        <div className="stat-card">
          <h3>Total Downloads</h3>
          <p>86</p>
        </div>

        <div className="stat-card">
          <h3>Unauthorized Uses</h3>
          <p className="danger">2</p>
        </div>

        <div className="stat-card">
          <h3>Active Watermarks</h3>
          <p>12</p>
        </div>
      </div>

      {/* RECENT ACTIVITY */}
      <div className="activity-section">
        <h2>Recent Activity</h2>

        <table className="activity-table">
          <thead>
            <tr>
              <th>Image</th>
              <th>Action</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>nature.jpg</td>
              <td>Downloaded</td>
              <td>10 mins ago</td>
            </tr>
            <tr>
              <td>logo.png</td>
              <td>Unauthorized Use Detected</td>
              <td>2 hours ago</td>
            </tr>
            <tr>
              <td>product.jpg</td>
              <td>Downloaded</td>
              <td>Yesterday</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;
