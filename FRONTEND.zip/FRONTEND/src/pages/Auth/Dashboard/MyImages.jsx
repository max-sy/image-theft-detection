import "./MyImages.css";
import { Link } from "react-router";

const MyImages = () => {
  // Temporary static data
  const images = [
    {
      id: 1,
      name: "nature.jpg",
      src: "https://via.placeholder.com/300x200?text=Nature",
    },
    {
      id: 2,
      name: "product.png",
      src: "https://via.placeholder.com/300x200?text=Product",
    },
    {
      id: 3,
      name: "logo.jpg",
      src: "https://via.placeholder.com/300x200?text=Logo",
    },
  ];

  return (
    <div className="my-images-page">
      <h1>My Protected Images</h1>

      <div className="images-grid">
        {images.map((img) => (
          <div key={img.id} className="image-card">
            <img src={img.src} alt={img.name} />
            <h3>{img.name}</h3>

            <div className="image-actions">
              <button className="secondary-btn">View</button>
              <button className="primary-btn">Download</button>
            </div>
            <Link to={"/"}>Home</Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyImages;
