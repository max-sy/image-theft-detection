import { useState } from "react";
import "./UploadImage.css";
import { Link } from "react-router";

const UploadImage = () => {
  const [preview, setPreview] = useState(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
    }
  };

  return (
    <div className="upload-page">
      <h1>Upload & Protect Image</h1>

      <div className="upload-card">
        <label className="upload-box">
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            hidden
          />
          <p>Click or drag an image here</p>
          <span>Supported: JPG, PNG</span>
        </label>

        {preview && (
          <div className="preview-section">
            <h3>Preview</h3>
            <img src={preview} alt="Preview" />
          </div>
        )}

        <button className="primary-btn upload-btn">
          Protect Image
        </button>
        <Link to={"/"}>Home</Link>
      </div>
    </div>
  );
};

export default UploadImage;
