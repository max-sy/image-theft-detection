import "./css/Extra.css";

const Extra = () => {
  return (
    <div className="page">
      <h1>Extra</h1>
      <p>Additional features and experiments.</p>
    </div>
  );
};

export default Extra;
