import "./css/Home.css";

const Home = () => {
  return (
    <div className="home-page">

      {/* HERO SECTION */}
      <section className="hero">
        <h1>Protect Your Images with Invisible Watermarks</h1>
        <p>
          Secure your digital images, track downloads, and detect unauthorized usage
          using advanced invisible watermarking technology.
        </p>
        <div className="hero-buttons">
          <button className="primary-btn">Get Started</button>
          <button className="secondary-btn">Learn More</button>
        </div>
      </section>

      {/* PROBLEM SECTION */}
      <section className="problem">
        <h2>The Problem</h2>
        <p>
          Creators lose control of their images due to unauthorized downloads,
          reposting without credit, and commercial misuse.
        </p>
      </section>

      {/* SOLUTION SECTION */}
      <section className="solution">
        <h2>Our Solution</h2>
        <ul>
          <li>✔ Embed invisible, traceable watermarks</li>
          <li>✔ Track image downloads and sharing</li>
          <li>✔ Detect misuse even after editing</li>
          <li>✔ Alert owners instantly</li>
        </ul>
      </section>

      {/* HOW IT WORKS */}
      <section className="how-it-works">
        <h2>How It Works</h2>
        <div className="steps">
          <div className="step">1. Upload Image</div>
          <div className="step">2. Watermark Embedded</div>
          <div className="step">3. Track Downloads</div>
          <div className="step">4. Get Alerts</div>
        </div>
      </section>

      {/* CALL TO ACTION */}
      <section className="cta">
        <h2>Start Protecting Your Work Today</h2>
        <button className="primary-btn">Create Free Account</button>
      </section>

    </div>
  );
};

export default Home;
