import "./css/Login.css";

const Login = () => {
  return (
    <div className="auth">
      <h2>Login</h2>
      <input placeholder="Email" />
      <input type="password" placeholder="Password" />
      <button>Login</button>
    </div>
  );
};

export default Login;
