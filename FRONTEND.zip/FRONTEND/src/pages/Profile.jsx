import { useEffect, useState } from "react";
import "./css/Profile.css";

const Profile = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchMe = async () => {
    try {
      const res = await api.get("/api/auth/me");
      setUser(res.data.user);
    } catch (error) {
      console.log("Profile fetch error:", error?.response?.data || error.message);
      setUser(null);
    } finally {
      setLoading(false);
    }
  };


  // ✅ Load user from localStorage
  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    } else {
      setUser(null);
    }
  }, []);

  if (!user) {
    return (
      <div className="profile-page">
        <h1>Profile</h1>
        <p>No user found. Please login again.</p>
      </div>
    );
  }

  return (
    <div className="profile-page">
      <h1>My Profile</h1>

      <div className="profile-card">
        <div className="profile-row">
          <span className="label">Name</span>
          <span className="value">{user.name}</span>
        </div>

        <div className="profile-row">
          <span className="label">Email</span>
          <span className="value">{user.email}</span>
        </div>

        <div className="profile-row">
          <span className="label">User ID</span>
          <span className="value">{user.id}</span>
        </div>
      </div>
    </div>
  );
};

export default Profile;
