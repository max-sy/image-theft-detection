import "./css/Settings.css";

const Settings = () => {
  return (
    <div className="page">
      <h1>Settings</h1>
      <p>Application settings will be configured here.</p>
    </div>
  );
};

export default Settings;
