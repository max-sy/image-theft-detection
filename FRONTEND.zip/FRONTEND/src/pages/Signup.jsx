import "./css/Signup.css";

const Signup = () => {
  return (
    <div className="auth">
      <h2>Signup</h2>
      <input placeholder="Name" />
      <input placeholder="Email" />
      <input type="password" placeholder="Password" />
      <button>Create Account</button>
    </div>
  );
};

export default Signup;
