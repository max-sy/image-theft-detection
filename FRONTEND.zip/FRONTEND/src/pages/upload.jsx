import { useState } from "react";
import API from "../services/api";

export default function Upload() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    const selected = e.target.files[0];

    if (!selected) return;

    setFile(selected);
    setPreview(URL.createObjectURL(selected));
    setMessage("");
  };

  const handleUpload = async () => {
    try {
      setMessage("");

      if (!file) {
        setMessage("❌ Please select an image first!");
        return;
      }

      const formData = new FormData();
      formData.append("image", file);

      const res = await API.post("/images/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      setMessage("✅ Image uploaded successfully!");
      console.log("Uploaded:", res.data);

      // optional reset
      setFile(null);
      setPreview("");
    } catch (err) {
      setMessage(
        "❌ Upload failed: " + (err.response?.data?.message || err.message)
      );
    }
  };

  return (
    <div style={{ padding: "30px" }}>
      <h2>Upload Image</h2>

      <input type="file" accept="image/*" onChange={handleChange} />

      {preview && (
        <div style={{ marginTop: "20px" }}>
          <p><b>Preview:</b></p>
          <img
            src={preview}
            alt="preview"
            style={{
              width: "250px",
              height: "250px",
              objectFit: "cover",
              borderRadius: "10px",
              border: "1px solid #ccc",
            }}
          />
        </div>
      )}

      <button
        onClick={handleUpload}
        style={{
          marginTop: "20px",
          padding: "10px 20px",
          cursor: "pointer",
        }}
      >
        Upload
      </button>

      {message && <p style={{ marginTop: "15px" }}>{message}</p>}
    </div>
  );
}
