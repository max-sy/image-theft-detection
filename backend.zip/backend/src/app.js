// import express from "express";
// import path from "path";
// import imageRoutes from "./routes/imageRoutes.js";
// import cors from "cors";
// import morgan from "morgan";
// import authRoutes from "./routes/authRoutes.js";


// const app = express();


// // Serve uploaded images publicly
// app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

// // Image Routes
// app.use("/api/images", imageRoutes);


// app.use(cors({
//   origin: "http://localhost:5173", // Vite frontend
//   credentials: true
// }));
// app.use(express.json());
// app.use(morgan("dev"));

// app.get("/", (req, res) => {
//   res.json({ message: "✅ ITD Backend is running..." });
// });
// app.get("/.well-known/appspecific/com.chrome.devtools.json", (req, res) => {
//   res.status(204).end();
// });


// // Routes
// app.use("/api/auth", authRoutes);



// export default app;



import express from "express";
import cors from "cors";
import morgan from "morgan";
import path from "path";
import authRoutes from "./routes/authRoutes.js";
import imageRoutes from "./routes/imageRoutes.js";




const app = express();

app.use(cors({ origin: "http://localhost:5173", credentials: true }));
app.use(express.json());
app.use(morgan("dev"));

// ✅ Serve uploads folder
app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

// ✅ Routes
app.use("/api/auth", authRoutes);
app.use("/api/images", imageRoutes);

app.get("/", (req, res) => {
  res.json({ message: "✅ ITD Backend is running..." });
});

export default app;
