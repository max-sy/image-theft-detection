import mongoose from "mongoose";

const imageSchema = new mongoose.Schema(
  {
    ownerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    originalName: { type: String, required: true },
    fileName: { type: String, required: true },
    filePath: { type: String, required: true },

    mimeType: { type: String, required: true },
    size: { type: Number, required: true },
  },
  { timestamps: true }
);

export default mongoose.model("Image", imageSchema);
